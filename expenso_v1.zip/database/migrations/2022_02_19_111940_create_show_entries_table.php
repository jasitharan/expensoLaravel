<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('show_entries', function (Blueprint $table) {
            $table->id();
            $table->integer('expense_types')->default(10);
            $table->integer('expenses')->default(10);
            $table->integer('users')->default(10);
            $table->integer('companies')->default(10);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('show_entries');
    }
};
