<?php $__env->startSection('expense_types-list-active','active'); ?>
<?php $__env->startSection('edit-hidden','d-none'); ?>



<?php $__env->startSection('expense_types-section'); ?>


<div class="card-body">
    
    <div class="d-flex flex-row justify-content-between">
      
      
        
        <div class="d-flex flex-row align-items-center">
            <div class="card-title text-center m-2"><h6 class="p-1 mt-2">Show</h6></div>
            <form action="<?php echo e(url('show_entries')); ?>" method="post" name="show-entries-form">
              <input name="_method" type="hidden" value="patch">
              <?php echo csrf_field(); ?>
              <select class="form-select" aria-label="Default select example" id='expense_types-limit' name='expense_types-limit' onchange="javascript: submitEntries()">
                <option value="10" <?php echo e($limit == 10? 'selected="selected"' : ''); ?>>10</option>
                <option value="25" <?php echo e($limit == 25? 'selected="selected"' : ''); ?>>25</option>
                <option value="50" <?php echo e($limit == 50? 'selected="selected"' : ''); ?>>50</option>
                <option value="100" <?php echo e($limit == 100? 'selected="selected"' : ''); ?>>100</option>
              </select>
            </form>
           
            <div class="card-title text-center m-2"><h6 class="p-1 mt-2">Entries</h6></div>
        </div>
        
        <nav class="navbar navbar-light bg-light">
         
              <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" name="search" id="search" value="<?php echo e(app('request')->input('search')); ?>" onchange="javascript: searchTable()">
       
          </nav>
        
        
    </div>
    
    <div class="m-4">
        <table class="table table-striped table-valign-middle">
            <thead>
                <tr>
                  <th>Image</th>
                    <th>
                      <div ><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('expType', 'Expense Type  '));?></div>
                      </th>
                    <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('expCostLimit', 'Expense Cost Limit  '));?>
                    </th>
                    <th>Modified By
                    </th>
                    <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('created_at', 'Created  '));?></th>
                  
                    <th><div>Actions</div></th>
                </tr>
            </thead>
            <tbody>
                
               <?php if(count($expenseTypes) > 0): ?>
                 <?php $__currentLoopData = $expenseTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expenseType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr class="align-middle">
                   <td>
                        <img  alt="60x60" width="60px" height="60px" src="<?php echo e($expenseType->url_image); ?>" data-holder-rendered="true">
                    <td><?php echo e($expenseType->expType); ?></td>
                    <td><?php echo e($expenseType->expCostLimit); ?></td>
                    <td><?php echo e($expenseType->modifedBy); ?></td>
                    <td><?php echo e($expenseType->created_at); ?></td>
                   
                    <td>
                      <form method="POST" action="<?php echo e(url('expense_types/'.$expenseType->id)); ?>" accept-charset="UTF-8">
                        <input name="_method" type="hidden" value="DELETE">
                        <?php echo csrf_field(); ?>
                        <div class="btn-group">
                        
                          
                        
                            <a href="<?php echo e(url('expense_types/'.$expenseType->id.'/edit')); ?>" class="btn btn-link text-center">
                              <i class="fa fa-edit"></i>
                          </a>
                
                        
                        
                            <button type="submit" class="btn btn-link text-danger" onclick="return confirm('Are you sure?')"><i class="fa fa-trash"></i></button>
                        </div>
                        </form>
                    </td>
                </tr>
                     
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php endif; ?>
                     
           </tbody>
        </table>
    </div>
    
   
    
    <div class="d-flex flex-row justify-content-between">
      
        <div class="text-center m-2"><p>Showing <?php echo e($expenseTypes->count()); ?> of <?php echo e($expenseTypes->total()); ?> entries</p></div>
        <div class="d-flex justify-content-center">
          <?php echo $expenseTypes->appends(Request::except('page'))->render(); ?>

      </div>
    </div>
    
    

    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('expenseTypes.expense_types', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jasitharan/Desktop/Laravel Projects/expensoLaravel/resources/views/expenseTypes/get_expense_types.blade.php ENDPATH**/ ?>