<?php $__env->startSection('users-create-active','active'); ?>
<?php $__env->startSection('edit-hidden','d-none'); ?>

    

<?php $__env->startSection('users-section'); ?>

<div class="card-body">
  
  <form action="<?php echo e(url('users')); ?>" method="post" name="users-create-form" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="container px-4">
      <div class="row gx-5">
        <div class="col">
            
         <div>
          <h5 class="card-title mt-4">Name</h5>
          <input type="text" class="form-control" id="name" name="name">
          <div id="nameHelp" class="form-text">
             insert user name
            </div>
         </div>
         
         
         <div>
          <h5 class="card-title mt-4">Email</h5>
          <input type="email" class="form-control" id="email" name="email">
          <div id="emailHelp" class="form-text">
             insert user email
            </div>
         </div>

         
         <div>
          <h5 class="card-title mt-4">Password</h5>
          <input type="password" class="form-control" id="password" name="password">
          <div id="passwordHelp" class="form-text">
             insert user password
            </div>
         </div>

      
         
          
         
          <div class="mt-3 mb-4">
              <h5 class="card-title mb-3">Image</h5>
              <input class="form-control" type="file" id="url_image" name="url_image">
              <div id="url_imageHelp" class="form-text">
                  insert the image
                 </div>
            </div>
            
            
            
         <div class="mt-3">
              <h5 class="card-title mb-3">Company</h5>
            <select class="form-select" aria-label="Default select example" name="company_id">
              <?php if(count($companies) > 0): ?>
              <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option  value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </select>

            <div id="companyHelp" class="form-text">
              select company
             </div>
         </div>
            
       
            <div class="mt-3">
              <h5 class="card-title mb-3">Role</h5>
<select class="form-select" aria-label="Default select example" name="role">
  <option selected value="">Open this select roles</option>
  <option  value="admin">Admin</option>
  <option  value="employee">Employee</option>
  <option  value="supervisor">Supervisor</option>
  <option  value="financial_manager">Financial Manager</option>
</select>

<div id="exHelp" class="form-text">
  select role
 </div>
</div>
        </div>
       
 
    <div class="text-end mt-4">
      <a href="javascript: createUser()" class="btn btn-primary ">Save</a>
    </div>
  </form>

    
  </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jasitharan/Desktop/Laravel Projects/expensoLaravel/resources/views/users/create_users.blade.php ENDPATH**/ ?>