<?php $__env->startSection('expense-create-active','active'); ?>
<?php $__env->startSection('edit-hidden','d-none'); ?>

    

<?php $__env->startSection('expense-section'); ?>

<div class="card-body">
  
  <form action="<?php echo e(url('expenses')); ?>" method="post" name="expenses-create-form" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="container px-4">
      <div class="row gx-5">
        <div class="col">
            
         <div>
          <h5 class="card-title mt-4">Expense For</h5>
          <input type="text" class="form-control" id="expenseFor" name="expenseFor">
          <div id="expenseForHelp" class="form-text">
             insert Expense For
            </div>
         </div>

         
         <div class="mt-3">
              <h5 class="card-title mb-3">Expense Type</h5>
            <select class="form-select" aria-label="Default select example" name="expenseType_id">
              <option selected value="">Open this select expense type</option>
                          <?php if(count($expense_types) > 0): ?>
              <?php $__currentLoopData = $expense_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option  value="<?php echo e($expense_type->id); ?>"><?php echo e($expense_type->expType); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </select>

            <div id="expenseTypeHelp" class="form-text">
              select expense type
             </div>
         </div>
          
         
         
         <div>
          <h5 class="card-title mt-4">Expense Cost</h5>
          <input type=number step=any class="form-control" id="expenseCost" name="expenseCost">
          <div id="expenseCostHelp" class="form-text">
             insert Expense Cost
            </div>
         </div>
            
       
        </div>
        <div class="col">
          <div class="mt-3">
              <h5 class="card-title mb-3">User</h5>
            <select class="form-select" aria-label="Default select example" id='user_id' name="user_id">
              <option selected value="">Open this select user</option>
                          <?php if(count($users) > 0): ?>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option  value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </select>

      <div id="userHelp" class="form-text">
        select user
      </div>
       </div>


      <div>
        <h5 class="card-title mt-4">Created Date</h5>
          <input type=date class="form-control" id="createdDate" name="createdDate">
          <div id="createdDateHelp" class="form-text">
             select created date
            </div>
         </div>
            

            
 <div>
  <h5 class="card-title mt-4">Status</h5>
  <div class="form-check">
    <input class="form-check-input" type="radio" name="status" id="status"  value="Unknown" checked>
    <label class="form-check-label" for="status" >
      Unknown
    </label>
  </div>
  <div class="form-check">
    <input class="form-check-input" type="radio" name="status" id="status" value="Approved">
    <label class="form-check-label" for="status">
      Approve
    </label>
  </div>
  <div class="form-check">
    <input class="form-check-input" type="radio" name="status" id="status" value="Rejected">
    <label class="form-check-label" for="status">
      Reject
    </label>
  </div>
 </div>   
             
        </div>
      </div>
    </div>
 
    <div class="text-end mt-4">
      <a href="javascript: createExpense()" class="btn btn-primary ">Save</a>
    </div>
  </form>

    
  </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('expenses.expenses', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jasitharan/Desktop/Laravel Projects/expensoLaravel/resources/views/expenses/create_expenses.blade.php ENDPATH**/ ?>