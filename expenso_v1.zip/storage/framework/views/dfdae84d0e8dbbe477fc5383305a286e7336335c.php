<?php $__env->startSection('expense-list-active','active'); ?>
<?php $__env->startSection('edit-hidden','d-none'); ?>

    

<?php $__env->startSection('expense-section'); ?>
<div class="card-body">
    
    <div class="d-flex flex-row justify-content-between">
        
      <div class="d-flex flex-row align-items-center">
        <div class="card-title text-center m-2"><h6 class="p-1 mt-2">Show</h6></div>
        <form action="<?php echo e(url('show_entries')); ?>" method="post" name="show-entries-form">
          <input name="_method" type="hidden" value="patch">
          <?php echo csrf_field(); ?>
          <select class="form-select" aria-label="Default select example" id='expense-limit' name='expense-limit' onchange="javascript: submitEntries()">
            <option value="10" <?php echo e($limit == 10? 'selected="selected"' : ''); ?>>10</option>
            <option value="25" <?php echo e($limit == 25? 'selected="selected"' : ''); ?>>25</option>
            <option value="50" <?php echo e($limit == 50? 'selected="selected"' : ''); ?>>50</option>
            <option value="100" <?php echo e($limit == 100? 'selected="selected"' : ''); ?>>100</option>
          </select>
        </form>
       
        <div class="card-title text-center m-2"><h6 class="p-1 mt-2">Entries</h6></div>
    </div>
        
        <nav class="navbar navbar-light bg-light">
          <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" name="search" id="search" value="<?php echo e(app('request')->input('search')); ?>" onchange="javascript: searchTable()">
          </nav>
        
        
    </div>
    
    <div class="m-4">
        <table class="table table-striped table-valign-middle">
            <thead>
                <tr>
                 
                    <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('user_name', 'User  '));?></th>
                    <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('expenseType_name', 'ExpenseType Name  '));?></th>
                    <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('expenseFor', 'Expense For  '));?></th>
                    <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('expenseCost', 'Expense Cost  '));?></th>
                    <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('createdDate', 'Created Date '));?></th>
                    <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('status', 'Status  '));?></th>
                    <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('created_at', 'Created At '));?></th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                
               <?php if(count($expenses) > 0): ?>
                 <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr class="align-middle">
                    <td><?php echo e($expense->user_name); ?></td>
                    <td><?php echo e($expense->expenseType_name); ?></td>
                    <td><?php echo e($expense->expenseFor); ?></td>
                    <td><?php echo e($expense->expenseCost); ?></td>
                    <td><?php echo e($expense->createdDate); ?></td>
                    <td><?php echo e($expense->status); ?></td>
                    <td><?php echo e($expense->created_at); ?></td>
                    <td>
                        
                        <form method="POST" action="<?php echo e(url('expenses/'.$expense->id)); ?>" accept-charset="UTF-8">
                          <input name="_method" type="hidden" value="DELETE">
                          <?php echo csrf_field(); ?>
                          <div class="btn-group">
                            
                            
                          
                              <a href="<?php echo e(url('expenses/'.$expense->id.'/edit')); ?>" class="btn btn-link text-center">
                                <i class="fa fa-edit"></i>
                            </a>
                  
                          
                          
                              <button type="submit" class="btn btn-link text-danger" onclick="return confirm('Are you sure?')"><i class="fa fa-trash"></i></button>
                          </div>
                          </form>
                  
                    </td>
                </tr>
                     
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php endif; ?>
                     
           </tbody>
        </table>
    </div>
    
   
    
    <div class="d-flex flex-row justify-content-between">
        <div class="text-center m-2"><p>Showing <?php echo e($expenses->count()); ?> of <?php echo e($expenses->total()); ?> entries</p></div>
        <div class="d-flex justify-content-center">
        <?php echo $expenses->appends(Request::except('page'))->render(); ?>

      </div>
    </div>
    
    

    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('expenses.expenses', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jasitharan/Desktop/Laravel Projects/expensoLaravel/resources/views/expenses/get_expenses.blade.php ENDPATH**/ ?>