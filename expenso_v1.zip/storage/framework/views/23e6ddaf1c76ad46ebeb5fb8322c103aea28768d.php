<?php $__env->startSection('title','Companies'); ?>
<?php $__env->startSection('companies-active','active'); ?>

<?php $__env->startSection('content'); ?>
<div class="card  shadow-sm p-3 mb-5 bg-white rounded">
    <div class="card-header">
        <ul class="nav nav-tabs flex-row justify-content-start">
            <li class="nav-item">
              <a class="nav-link <?php echo $__env->yieldContent('companies-list-active'); ?>" href="<?php echo e(url('/companies?sort=created_at&direction=desc')); ?>">Companies List</a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?php echo $__env->yieldContent('companies-create-active'); ?>" href="<?php echo e(url('/companies/create')); ?>">Create Company</a>
            </li>
            <li class="nav-item <?php echo $__env->yieldContent('edit-hidden'); ?>">
              <a class="nav-link <?php echo $__env->yieldContent('companies-edit-active'); ?>" href="<?php echo e(url('/companies/edit')); ?>">Edit Company</a>
            </li>
          </ul>
    </div>
    <?php echo $__env->yieldContent('companies-section'); ?>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jasitharan/Desktop/Laravel Projects/expensoLaravel/resources/views/companies/companies.blade.php ENDPATH**/ ?>