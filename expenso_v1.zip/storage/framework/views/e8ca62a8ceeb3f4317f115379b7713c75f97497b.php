<?php $__env->startSection('title','Settings'); ?>
<?php $__env->startSection('settings-active','active'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

  <div class="row gutters-sm">
    <div class="col-md-4">
      <div class="card shadow-sm p-3 mb-5 bg-white rounded">
        <div class="card-body">
          <nav class="nav flex-column nav-pills nav-gap-y-1">
            <div>
              <h6 class="dropdown-header">Select Setting</h6>
              <a class="dropdown-item mb-1 <?php echo $__env->yieldContent('global-setting-active'); ?>" href="<?php echo e(url('settings/global')); ?>">Global Settings</a>
              <a class="dropdown-item mb-1 <?php echo $__env->yieldContent('notification-setting-active'); ?>" href="<?php echo e(url('settings/notification')); ?>">Notification</a>
              <a class="dropdown-item mb-1 <?php echo $__env->yieldContent('mail-setting-active'); ?>" href="<?php echo e(url('settings/mail')); ?>">Mail</a>
            </div>
          </nav>
        </div>
      </div>
    </div>
    <div class="col-md-8">
      <?php echo $__env->yieldContent('setting-content'); ?>
    </div>
  </div>

</div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jasitharan/Desktop/Laravel Projects/expensoLaravel/resources/views/settings/settings.blade.php ENDPATH**/ ?>