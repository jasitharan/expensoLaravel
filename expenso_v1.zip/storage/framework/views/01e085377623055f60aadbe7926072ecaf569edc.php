<?php $__env->startSection('title','Users'); ?>
<?php $__env->startSection('users-active','active'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow-sm p-3 mb-5 bg-white rounded">
    <div class="card-header">
        <ul class="nav nav-tabs flex-row justify-content-start">
            <li class="nav-item">
              <a class="nav-link <?php echo $__env->yieldContent('users-list-active'); ?>" href="<?php echo e(url('users?sort=created_at&direction=desc')); ?>">User List</a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?php echo $__env->yieldContent('users-create-active'); ?>" href="<?php echo e(url('users/create')); ?>">Create User</a>
            </li>
            <li class="nav-item <?php echo $__env->yieldContent('edit-hidden'); ?>">
              <a class="nav-link <?php echo $__env->yieldContent('users-edit-active'); ?>"> Edit User</a>
            </li>
          </ul>
    </div>
   <?php echo $__env->yieldContent('users-section'); ?>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jasitharan/Desktop/Laravel Projects/expensoLaravel/resources/views/users/users.blade.php ENDPATH**/ ?>