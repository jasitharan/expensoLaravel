<?php $__env->startSection('title','Expenses'); ?>
<?php $__env->startSection('expense-active','active'); ?>



<?php $__env->startSection('content'); ?>
<div class="card shadow-sm p-3 mb-5 bg-white rounded">
    <div class="card-header">
        <ul class="nav nav-tabs flex-row justify-content-start">
            <li class="nav-item">
              <a class="nav-link <?php echo $__env->yieldContent('expense-list-active'); ?>" href="<?php echo e(url('expenses?sort=created_at&direction=desc')); ?>">Expense List</a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?php echo $__env->yieldContent('expense-create-active'); ?>" href="<?php echo e(url('expenses/create')); ?>">Create Expense</a>
            </li>
            <li class="nav-item <?php echo $__env->yieldContent('edit-hidden'); ?>">
              <a class="nav-link <?php echo $__env->yieldContent('expense-edit-active'); ?>"> Edit Expense</a>
            </li>
          </ul>
    </div>
   <?php echo $__env->yieldContent('expense-section'); ?>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jasitharan/Desktop/Laravel Projects/expensoLaravel/resources/views/expenses/expenses.blade.php ENDPATH**/ ?>