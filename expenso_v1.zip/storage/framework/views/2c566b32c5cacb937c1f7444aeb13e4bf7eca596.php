<?php $__env->startSection('notification-setting-active','active'); ?>



<?php $__env->startSection('setting-content'); ?>

<div class="card shadow-sm p-3 mb-5 bg-white rounded">
    <div class="card-header">
      Firebase Push Notification Settings
  </div>
  <form action="<?php echo e(url('settings/notification')); ?>" method="post" name="setting-notification-form">
    <input name="_method" type="hidden" value="patch">
    <?php echo csrf_field(); ?>
    <div class="card-body">

   
      <h5 class="card-title mt-4">Firebase Cloud Messaging Key</h5>
      
      <div class="mb-4 mt-3">
        <input type="text" class="form-control" id="fcm_key" name="fcm_key" value="<?php echo e($settings->fcm_key); ?>">
        <div id="fcm_keyHelp" class="form-text">
          Insert Firebase Cloud Messaging Key <a href="https://console.firebase.google.com">( https://console.firebase.google.com/ )</a>
          </div>
      </div>
      
      <div class="text-end">
        <a href="javascript: saveSettingNotification()" class="btn btn-primary ">Save</a>
      </div>
     
    </div>
  </form>
 
  </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('settings.settings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jasitharan/Desktop/Laravel Projects/expensoLaravel/resources/views/settings/notification_setting.blade.php ENDPATH**/ ?>