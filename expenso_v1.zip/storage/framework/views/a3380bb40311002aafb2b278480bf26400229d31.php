<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('dashboard-active','active'); ?>

<?php $__env->startSection('content'); ?>


<div class="dashboard_cardview">
    
    <div class="cardview">
        <div class="card shadow-sm p-3 mb-5 bg-info rounded  bg-info text-dark mb-3" style="max-width: 18rem;">
            <div class="card-body">
               
                    <i class='bx bxs-user mb-3' style="font-size:32px"></i>
            
                
                    <h5 class="card-title">Total Employee</h5>
              <p class="card-text">Registerd Employee
            </p>
            <h2 class="card-title"><?php echo e($total_users); ?></h2>
              
            </div>
          </div>
    </div>
    
    <div class="cardview">
        <div class="card shadow-sm p-3 mb-5 bg-info rounded text-dark bg-info mb-3" style="max-width: 18rem;">
            <div class="card-body">
               
                    <i class='bx bx-money mb-3' style="font-size:32px"></i>
              
                
                    <h5 class="card-title">Total Expenses</h5>
              <p class="card-text">Created Via Employee
            </p>
            <h2 class="card-title"><?php echo e($total_expenses); ?></h2>
              
            </div>
          </div>
    </div>
    
    
    <div class="cardview">
        <div class="card shadow-sm p-3 mb-5 bg-info rounded text-dark bg-info mb-3" style="max-width: 18rem;">
            <div class="card-body">
               
                    <i class='bx bxs-wallet mb-3' style="font-size:32px"></i>
              
                
                    <h5 class="card-title">Total ExpenseTypes</h5>
              <p class="card-text">Active ExpenseTypes
            </p>
            <h2 class="card-title"><?php echo e($total_expenseTypes); ?></h2>
              
            </div>
          </div>
    </div>
    
   
    
  
   
</div>


<div class="card shadow-sm p-3 mb-5 bg-white rounded">
    <h5 class="card-header">Recent 5 Pending Expenses</h5>
    <div class="card-body">
        <table class="table table-striped table-valign-middle">
            <thead>
                <tr>
                    <th>Employee</th>
                    <th>Expense For</th>
                    <th>Expense Cost</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                
            <?php if(count($expenses) > 0): ?>
                 <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr class="align-middle">
                    <td><?php echo e($expense->user_name); ?></td>
                    <td><?php echo e($expense->expenseFor); ?></td>
                    <td><?php echo e($expense->expenseCost); ?></td>
                    <td>
                        
                        <form method="POST" action="<?php echo e(url('pending_expenses/'.$expense->id)); ?>" accept-charset="UTF-8" name="status-update-form">
                          <input name="_method" type="hidden" value="PATCH">
                          <?php echo csrf_field(); ?>
                          <div class="btn-group">
                            
                            
                      
                              <a href="<?php echo e(url('expenses/'.$expense->id.'/edit')); ?>" class="btn btn-link text-center">
                                <i class="fa fa-eye"></i>
                              </a>
                  
                              <div>
                               <input type="hidden" name="status" value="Approved">
                               <button type="button" class="btn btn-link text-success" onclick="javascript: statusUpdate('status-update-form')"><i class="fa fa-check"></i></button>
                              </div>
                            
                              
                          </div>
                          </form>
                          <form method="POST" action="<?php echo e(url('pending_expenses/'.$expense->id)); ?>" accept-charset="UTF-8" name="status-update-form2">
                          <input name="_method" type="hidden" value="PATCH">
                          <?php echo csrf_field(); ?>
                          <div class="btn-group">
                            
                          <div>
                              <input type="hidden" name="status" value="Rejected">
                               <button type="button" class="btn btn-link text-danger" onclick="javascript: statusUpdate('status-update-form2')"><i class="fa fa-times"></i></button>
                              </div>
                            
                              
                          </div>
                          </form>
                          
                           
                       
                  
                    </td>
                </tr>
                     
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php endif; ?>
                
                
           </tbody>
        </table>
    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jasitharan/Desktop/Laravel Projects/expensoLaravel/resources/views/dashboard.blade.php ENDPATH**/ ?>