<?php $__env->startSection('users-edit-active','active'); ?>

    

<?php $__env->startSection('users-section'); ?>

<div class="card-body">

  <form action="<?php echo e(url('users/'.$user->id)); ?>" method="post" name="users-edit-form" enctype="multipart/form-data">
    <input name="_method" type="hidden" value="PUT">
    <?php echo csrf_field(); ?>
  
    <div class="container px-4">
      <div class="row gx-5">
        <div class="col">
            
         <div>
          <h5 class="card-title mt-4">Name</h5>
          <input type="text" class="form-control" id="name" name="name" value="<?php echo e($user->name); ?>">
          <div id="nameHelp" class="form-text">
             insert user name
            </div>
         </div>
         
         
         <div>
          <h5 class="card-title mt-4">Email</h5>
          <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>">
          <div id="emailHelp" class="form-text">
             insert user email
            </div>
         </div>
         
         
         
         <div class="mt-3">
              <h5 class="card-title mb-3">Company</h5>
            <select class="form-select" aria-label="Default select example" name="company_id">
              <?php if(count($companies) > 0): ?>
              <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <?php if(($company->name == $user->company_name)): ?>
              <option selected value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
              <?php else: ?>
              <option  value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </select>

            <div id="companyHelp" class="form-text">
              select company
             </div>
         </div>
      
         
          
         
          <div class="mt-3 mb-4">
              <h5 class="card-title mb-3">Image</h5>
              <input class="form-control" type="file" id="url_image" name="url_image">
              <div id="url_imageHelp" class="form-text">
                  insert the image
                 </div>
                 <img height=60px width=60px src='<?php echo e($user->url_image); ?>' class="rounded float-left" alt="user_image">  
            </div>
            
       
            <div class="mt-3">
              <h5 class="card-title mb-3">Role</h5>
         <select class="form-select" aria-label="Default select example" name="role">
            <option  value="">Open this select roles</option>
            <option <?php echo e($user->role == 'admin' ? "selected" : ""); ?> value="admin">Admin</option>
            <option <?php echo e($user->role == 'employee' ? "selected" : ""); ?>  value="employee">Employee</option>
            <option <?php echo e($user->role == 'supervisor' ? "selected" : ""); ?> value="supervisor">Supervisor</option>
            <option <?php echo e($user->role == 'financial_manager' ? "selected" : ""); ?> value="financial_manager">Financial Manager</option>
</select>

<div id="exHelp" class="form-text">
  select role
 </div>
</div>
        </div>
       
 
    <div class="text-end mt-4">
      <a href="javascript: editUser()" class="btn btn-primary ">Save</a>
    </div>
  
  </form>
  </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jasitharan/Desktop/Laravel Projects/expensoLaravel/resources/views/users/edit_users.blade.php ENDPATH**/ ?>